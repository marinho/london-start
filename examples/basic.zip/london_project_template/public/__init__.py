# Registered templates
from london.apps.themes.registration import register_template
register_template("home", mirroring="home.html")

